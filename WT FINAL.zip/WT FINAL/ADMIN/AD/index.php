  <!DOCTYPE html>
  <html lang="">
  	<head>
  		<meta charset="utf-8">
  		<meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<title>Waste management system</title>
  
  		<!-- Bootstrap CSS -->
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  		<!-- Google Fonts -->
  		<link href='https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700' rel='stylesheet' type='text/css'>
  		<!-- Font Awesome -->
  		<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css' rel='stylesheet' type='text/css'>
  		<!-- Style -->
  		<link href='style.css' rel='stylesheet' type='text/css'>
       <link rel="stylesheet"  href="https://code.jquery.com/jquery-3.3.1.js">
  		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  		<!--[if lt IE 9]>
  			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
  			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  		<![endif]-->

       
     
       <style type="text/css">
        #a{
            height: 20px;
            width: 100px;
            background-color: : green;
            border-width: 2px;
            border-color: white;
            
        }

         #b{
            height: 20px;
            width: 100px;
            background-color: : green;
            border-width: 2px;
            border-color: white;
            
            
        }
      </style>
      <script type="text/javascript">
        function  givealert1(){
          alert("The number of containers will be decreased soon in given  locality");

        }


        function  givealert2(){
          alert("Some kind of problem occured try again");

        }

        function  givealertfortruck1(){
          alert("The number of Trucks will be decreased soon in given  locality ");

        }


        function  givealertfortruck2(){
          alert("Some kind of problem occured try again ");

        }
       
      </script>


  	</head>
  	<body>

     


      <?php
       $servername = "localhost";
$username = "username";
$password = "password";
$dbname = "wm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



      ?>
  		<nav class="navbar navbar-default" role="navigation">
  			<div class="container">
  				<!-- Brand and toggle get grouped for better mobile display -->
  				<div class="navbar-header">
  					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
  						<span class="sr-only">Toggle navigation</span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  					</button>
  					<a class="navbar-brand" href="#">Waste_management_system</a>
  				</div>
  		
  				<!-- Collect the nav links, forms, and other content for toggling -->
  				<div class="collapse navbar-collapse navbar-ex1-collapse">
  					<ul class="nav navbar-nav navbar-right">
  						
  						<li><a href="#">SUGGESTIONS</a></li>
  						<li><a href="#">LOGOUT</a></li>
  						
  					</ul>
  				</div><!-- /.navbar-collapse -->
  			</div>
  		</nav>
		
		<!-- START SECTION -->
  		<div class="section hero text-center background-dark dark-bg">
  			<div class="background-image" style="background: url('https://www.eppm.com/downloads/5663/download/shutterstock_345587621.jpg?cb=0e6562f30b89cedf5c250e2f9bc1ea78') no-repeat center center; background-size: cover; opacity: .6;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h2>Click here to reduce </h2>
  						<p class="lead">CONTAINER OR TRUCKS IN LOCLALITY</p>
  						<ul class="list-inline">
  							<li><a href="#ref" title="Learn More" class="btn btn-md btn-info" >Click </a></li>
  					
  						</ul>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div class="section background-light">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12 text-center">
  						<h2 class="section-title">Our Services</h2>
  						<p class="section-description">SERVICES RELATED TO THE REQUEST FROM THE USER.</p>
  					</div>
  					<div class="col-md-6">
  						<div class="service-block text-center">
  							<i class="fa fa-rocket"></i>
  							<h3>INCREASE THE NUMBER OF CONTAINER</h3>
  							<p>AFTER  GETTING THE REQUEST FROM THE USER WE CHECK REASON AND WE FIND THE REASON APPROPRIATE WE INCEREASE  THE NUMBER OF CONTAINER IN THAT  LOCALITY  </p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  					<div class="col-md-6">
  						<div class="service-block text-center">
  							<i class="fa fa-rocket"></i>
  							<h3>INCREASE THE NUMBER OF TRUCKS</h3>
  							<p>AFTER  GETTING THE REQUEST FROM THE USER WE CHECK REASON AND WE FIND THE REASON APPROPRIATE WE INCEREASE  THE NUMBER OF TRUCKS  IN THAT  LOCALITY.WE HIRE NEW DRIVERS ETC</p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  					  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		
  		<!--/.section -->

  		<!-- START SECTION -->
  		
  		<!--/.section -->

  		<!-- START SECTION -->
      <!--SEXTION FOR  REQUEST FOR  INCREASING CONTAINER IN THE LOCALITY-->
  		<div  id="ref"class="section">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12 text-center">
  						<h2 class="section-title">DECREASE THE NUMBER OF CONTAINER </h2>
  						<p class="section-description">IN THE SPECIFIED LOCALITY</p>
               <p class="section-description">PLEASE ENTER THE LOCALITY NAME WHICH ARE UNDER OUR CONTROL</p>
  					</div>
  					<div class="col-md-8 col-md-offset-2">
  						<form action="index.php" id="contact" method="post" class="form" role="form">
							<div class="row">
								<div class="col-md-6 form-group">
									<input class="form-control" id="name" name="name" placeholder="Localityname" type="text" required />
								</div>
								<div class="col-md-6 form-group">
									<input class="form-control" id="email" name="email" placeholder="Email" type="email" required />
								</div>
							</div>
							<br />
							<div class="row">
								<div class="col-md-12 form-group">
									<button class="btn btn-primary" name="submit" type="submit">REDUCE</button>
								</div>
							</div>
						</form>
             
  					</div>
  				</div><!--/.row-->
  			</div><!--/.container-->
  		</div>
  		<!--/.section -->
      <?php
      
      if(isset($_POST['submit'])){
        
        $Localityname=$_POST['name'];
        $email=$_POST['email'];
        
        $sql="select * from localitydataforwastestorage where  locality='$Localityname'";
        $result=mysqli_query($conn,$sql);

        if($result) {
    if(mysqli_num_rows($result) > 0) {

        $sql1="update localitydataforwastestorage set number_of_container=number_of_container-1   where  locality='$Localityname'";
        $result1=mysqli_query($conn,$sql1);
        echo '<h2 style="text-align:center;color:green;">THE NUMBER OF CONTAINER REDUCED SUCCESSFULLY </h2>';
        echo "<script>givealert1();</script>";
        //sending mail to the department
        
       }else
       {
         echo '<h2 style="text-align:center;color:green;">THE CONTAINERS ARE NOT REDUCED SUCCESSFULLY</h2>'; 
          echo "<script>givealert2();</script>";
       }


      }
      else
      {

        echo '<h2 style="text-align:center;color:green;">THE CONTAINERS ARE NOT REDUCED SUCCESSFULLY</h2>';
         echo "<script>givealert2();</script>";
      }
    }
      ?>


      <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="section-title">REDUCE THE NUMBER OF  TRUCKS HERE</h2>
              
              
            </div>
            <div class="col-md-8 col-md-offset-2">
              <form  action="index.php"  id="contact" method="post" class="form" role="form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input class="form-control" id="name" name="name1" placeholder="Localityname" type="text" required />
                </div>
                <div class="col-md-6 form-group">
                  <input class="form-control" id="email" name="email1" placeholder="Email" type="email" required />
                </div>
              </div>
              
              <br />
              <div class="row">
                <div class="col-md-12 form-group">
                  <button class="btn btn-primary" name="submit1" type="submit">REDUCE</button>
                </div>
              
                 <?php
      
      if(isset($_POST['submit1'])){
        
        $Localityname=$_POST['name1'];
        $email=$_POST['email1'];
        
        $sql="select * from localitydataforwastestorage where  locality='$Localityname'";
        $result=mysqli_query($conn,$sql);


        if($result) {
    if(mysqli_num_rows($result) > 0) {

        $sql1="update localitydataforwastestorage set number_of_trucks=number_of_trucks-1   where  locality='$Localityname'";
        $result1=mysqli_query($conn,$sql1);
        
         echo '<h2 style="text-align:center;color:green;">THE NUMBER OF TRUCKS HAD BEEN REDUCED SUCCESSFULLY</h2>';  
          echo "<script>givealertfortruck1();</script>"; 
       }else
       {
           
         echo '<h2 style="text-align:center;color:green;">The TRUCKS ARE NOT REDUCED SUCCESSFULLY</h2>';
          echo "<script>givealertfortruck2();</script>";
       }


      }
      else
      {

        
        echo '<h2 style="text-align:center;color:green;">The TRUCKS ARE NOT REDUCED SUCCESSFYLLY</h2>'; 
         echo "<script>givealertfortruck2();</script>";
      }
    }
      ?>

              </div>
            </form>
            </div>
          </div><!--/.row-->
        </div><!--/.container-->
      </div>
       
      
  		<!-- START SECTION -->
  		<div class="section hero text-center background-light">
  			<div class="background-image" style="background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRb5_s13TyKyWtcSTLV5lxd1PueSxH_Q1wKRI_pA6r7v1a72ezL') no-repeat fixed center center; background-size: cover; opacity: .4;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h3 class="text-uppercase letter-spacing-md font-weight-lg margin-zero">USE 3 R's TO REDUCE AVERAGE WASTE GENERATED PER DAY</h3>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div class="section background-dark dark-bg">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-3">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">WORKING HOURS</h3>
  						<p>8 AM :12 PM</p>
  						<p><BR>1 PM :6 PM</p>
              <p><BR>7 PM :10 PM</p>
  					</div>
  					<div class="col-md-4 col-md-offset-1">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">OUR ADDRESS</h3>
  						<address>
							<strong>BUILDING NO.3</strong><br>
						 	LOHIYA STREET,GHATKOPAR<br>
						 	MUMBAI-400064<br>
						  (123) 456-7890
						</address>
						<address>
							<strong>Full Name</strong><br>
						 	<a href="mailto:#">Mumbai@wastemanagement.com</a>
						</address>
  					</div>
  					<div class="col-md-4">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">Major contacts</h3>
  						<address>
							555-555555-55<br>
						 	44-4444444-444<br>
						 	55-55555-555<br>
						 	
						</address>
						<address>
													</address>
  					</div>
  					<div class="col-md-12 margin-top-md margin-bottom-md" style="opacity: .2;">
  						<hr/>
  					</div>
  					<div class="col-md-12 margin-top-md text-center font-size-sm text-upercase">
  						<p><a href="http://nomadtheme.com" title="nomadtheme"><strong>Mumbai@wastemanagement.com</strong></a></p>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->
  
  		<!-- jQuery -->
  		<script src="//code.jquery.com/jquery.js"></script>
  		<!-- Bootstrap JavaScript -->
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  	</body>
  </html>