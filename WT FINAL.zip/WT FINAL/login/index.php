﻿

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Transparent Login Form</title>
		<link rel="stylesheet" href="style1.css">
	</head>
	<body>
		<?php
$username="username";
$password="password";
$servername="localhost";
$db_name="wm";
$conn=mysqli_connect($servername,$username,$password,$db_name);
if(!$conn)
{
die("Connection Failed".mysqli_connect_error());
}
  if(isset($_POST['submit']))
  {
    $uname = $_POST['username'];
    $pword = $_POST['password'];
    //$password = md5($password);
    $sql = "select * from users where username='$uname' and password='$pword'";
    if ($result=mysqli_query($conn,$sql))
      {
        $user_id=$uname;
        $rowcount=mysqli_num_rows($result);
        if($rowcount == 1)
        {
          if($uname == "admin")
          {
            setcookie('username',$user_id,time()+60*60*7);
          session_start();
          $_SESSION['username']=$user_id;
          header("Location: ../ADMIN/AD/index.php");
          }
          else
          {
          setcookie('username',$user_id,time()+60*60*7);
          session_start();
          $_SESSION['username']=$user_id;
          header("Location: ../homepage/AD/index.html");
          }
        }
        else {
          header("Location: index.php");
        }
      }
  }
$conn->close();
?>
		<div class="loginBox">
			<img src="user2.png" class="user">
			<h2>Log In Here</h2>
			<form method = "POST">
				<p>Email</p>
				<input type="text" name = "username" id="i1" placeholder="Enter Username" required>
				<p>Password</p>
				<input type="password" name = "password" id="i2" placeholder="••••••">
				<input type="submit" name="submit" value="Sign In" required>
				<a href="../signup/signup.php">NEW USER</a>

			</form>
		</div>
	</body>
</html>