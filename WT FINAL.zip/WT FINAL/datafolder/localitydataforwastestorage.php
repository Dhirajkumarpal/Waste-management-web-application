
<html>
<head>
	<title></title>
</head>
<body>
 
<?php


$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "WM";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "Create table  localitydataforwastestorage (
locality varchar(50) primary key,
number_of_container int ,
number_of_trucks int
)";



if ($conn->query($sql) === TRUE) {
    echo "Table localitydataforwastestorage created  successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$sql = "insert into localitydataforwastestorage values('Sion',8,3
)";



if ($conn->query($sql) === TRUE) {
    echo "row 1 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "insert into localitydataforwastestorage values('Kurla',7,4
)";



if ($conn->query($sql) === TRUE) {
    echo "row 2 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}


$sql = "insert into localitydataforwastestorage values('Chembur',9,4
)";



if ($conn->query($sql) === TRUE) {
    echo "row 3 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "insert into localitydataforwastestorage values('Kalyan',10,5
)";



if ($conn->query($sql) === TRUE) {
    echo "row 4 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "insert into localitydataforwastestorage values('Mira road',4,2)
)";



if ($conn->query($sql) === TRUE) {
    echo "row 5 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "insert into localitydataforwastestorage values('Dadar',6,3
)";



if ($conn->query($sql) === TRUE) {
    echo "row 6 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "insert into localitydataforwastestorage values('Byculla',12,6
)";



if ($conn->query($sql) === TRUE) {
    echo "row 7 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "insert into localitydataforwastestorage values('Dombivali',14,5
)";



if ($conn->query($sql) === TRUE) {
    echo "row 8 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}



$sql = "insert into localitydataforwastestorage values('Wadala',6,4
)";



if ($conn->query($sql) === TRUE) {
    echo "row 9 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}


$sql = "insert into localitydataforwastestorage values('Kandivali',14,8
)";



if ($conn->query($sql) === TRUE) {
    echo "row 10 inserted";
} else {
    echo "Error creating table: " . $conn->error;
}

$sql = "Create table  users (
username varchar(50) primary key,
password varchar(50) ,
email varchar(100)
)";



if ($conn->query($sql) === TRUE) {
    echo "Table users created  successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


$sql = "Create table  reason_for_increasing_container(
id int primary key,
reason varchar(200)
)";



if ($conn->query($sql) === TRUE) {
    echo "Table reason_for_increasing_container created  successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$sql = "insert into reason_for_increasing_container values(1,'INCREASE IN POPULATION'
)";



if ($conn->query($sql) === TRUE) {
    echo "row 1 inserted for table reason_for_increasing_container";
} else {
    echo "Error creating table: " . $conn->error;
}


$sql = "insert into reason_for_increasing_container values(1,'OCCURENCE OF FESTIVAL'
)";



if ($conn->query($sql) === TRUE) {
    echo "row 2 inserted for table reason_for_increasing_container";
} else {
    echo "Error creating table: " . $conn->error;
}

$sql = "insert into reason_for_increasing_container values(1,'OVERFLOW OF CONTAINER'
)";



if ($conn->query($sql) === TRUE) {
    echo "row 3 inserted for table reason_for_increasing_container";
} else {
    echo "Error creating table: " . $conn->error;
}

?>
</body>
</html>