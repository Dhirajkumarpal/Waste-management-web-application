﻿<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Transparent Login Form</title>
		<link rel="stylesheet" href="style2.css">
	</head>
	<body>

		<?php
		if(isset($_POST['submit']))
  {
$username="username";
$password="password";
$servername="localhost";
$db_name="wm";
$conn=mysqli_connect($servername,$username,$password,$db_name);
if(!$conn)
{
die("Connection Failed".mysqli_connect_error());
}
echo "Connection Successful"."<br>";
  $uname = $_POST['username'];
  $pword = $_POST['password'];
  //$pword = md5($password);
  $email = $_POST['email'];
  //$aadhaarno = $_POST['aadhaarno'];
//print_r($aadhaarno);
//print_r($phoneno);
$sql = "insert into users(username,password,email) values ('$uname','$pword','$email')";
#$result = mysqli_query($conn,$sql);
if ($conn->query($sql) === TRUE) {
    header("Location: ../login/index.php");
    #echo "Successful";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();}
?>


		<div class="loginBox">
			<img src="user3.png" class="user">
			<h2>First Time User<br>Sign Up Here</h2>
			
			<form method="POST">
				<p>Username</p>
				<input type="text" name="username" placeholder="Enter Username">
				<p>Email</p>
				<input type="text" name="email" placeholder="Enter Email">
				<p>Password</p>
				<input type="password" name="password" placeholder="••••••">
				<input type="submit" name="submit" value="Sign Up">
				
			</form>
		</div>
	</body>
</html>
