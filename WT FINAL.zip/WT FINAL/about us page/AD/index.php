  <!DOCTYPE html>
  <html lang="">
  	<head>
  		<meta charset="utf-8">
  		<meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<title>Waste management system</title>
  
  		<!-- Bootstrap CSS -->
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  		<!-- Google Fonts -->
  		<link href='https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700' rel='stylesheet' type='text/css'>
  		<!-- Font Awesome -->
  		<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css' rel='stylesheet' type='text/css'>
  		<!-- Style -->
  		<link href='style.css' rel='stylesheet' type='text/css'>
       <link rel="stylesheet"  href="https://code.jquery.com/jquery-3.3.1.js">
  		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  		<!--[if lt IE 9]>
  			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
  			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  		<![endif]-->

       
     
       <style type="text/css">
        #a{
            height: 20px;
            width: 100px;
            background-color: : green;
            border-width: 2px;
            border-color: white;
            
        }

         #b{
            height: 20px;
            width: 100px;
            background-color: : green;
            border-width: 2px;
            border-color: white;
            
            
        }
      </style>
      <script type="text/javascript">
        $(document).ready(function(){
          $("")
        })
      </script>

  	</head>
  	<body>

     



      
  		<nav class="navbar navbar-default" role="navigation">
  			<div class="container">
  				<!-- Brand and toggle get grouped for better mobile display -->
  				<div class="navbar-header">
  					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
  						<span class="sr-only">Toggle navigation</span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  					</button>
  					<a class="navbar-brand" href="#">Waste_management_system</a>
  				</div>
  		
  				<!-- Collect the nav links, forms, and other content for toggling -->
  				<div class="collapse navbar-collapse navbar-ex1-collapse">
  					<ul class="nav navbar-nav navbar-right">
  						<li><a href="#">HOME</a></li>
  						<li><a href="#">SEARCH LOCATION</a></li>
  						<li><a href="#">REQUEST</a></li>
  					
  						<li><a href="#">UPLOAD</a></li>
              <li><a href="#">LOGOUT</a></li>
  					</ul>
  				</div><!-- /.navbar-collapse -->
  			</div>
  		</nav>
		
		<!-- START SECTION -->
  		<div class="section hero text-center background-dark dark-bg">
  			<div class="background-image" style="background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoUhXD23BluX4LDFo0Rqq8-WPjF7TwWQsuCMig4NHVge10gD-J') no-repeat center center; background-size: cover; opacity: .4;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h2>Click here to KNOW MORE ABOUT US </h2>
  						
  						<ul class="list-inline">
  							<li><a href="#ref" title="Learn More" class="btn btn-md btn-info" >Click </a></li>
  					
  						</ul>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div id="ref" class="section background-light">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-6 text-center">
  						<h2 class="section-title">Our Services</h2>
  						<p class="section-description">SERVICES RELATED TO THE COLLECTION OF THE WASTE FROM EACH LOCALITY.</p>
  					</div>
  					<div class="col-md-12">
  						<div class="service-block text-center">
  							<i class="fa fa-rocket"></i>
  							<h3>COLLECTION</h3>
  							<p>AT 9 A.M ALL THE DRIVERS ARE ALERTED TO SO THAT  EACH CABN TAKE  ALLOTTEWD TRUCK TO THEIR ALLOTED  LOCALITY FOR WASTE COLLLECTION.WE MAKE SURE THSAT WE COVER ALL THE AREA UNDER OUR CONTROL .eVEN IF THE WASTE IS NOT COLLECTED FROM SOME LOCALITY THEN WEBSITES PROVIDES USER SOME FUNCTIONALITY SO THATTHEY CAN UPLOAD THE IMAGE SHOWING THAT THE WASTE HAS NOT BEEN COLLECTED FROM LOCALITY .IF ANY PEOPLE OF THE LOCALITY SEES THE CONTRAINER OVERFLOWING HE SHE CAN REQUEST USING THE WEBSITE TO REQUEST FOR INCREASING THE NUMBER OF CONTAINER    </p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  					<div class="col-md-6">
  						<div class="service-block text-center">
  							<i class="fa fa-rocket"></i>
  							<h3>COLLECTION</h3>
  							<p>A TRUCK CAN CARRY MAXIMUM 300KG OF WASTE FROM  ALLOTED LOCALITY IF THE WASTE GENERATED IS MORE THAN THE CAPACITY OF THE TRUCK ALLOTED THAN WE INCTREASE THE NUMBER OF TRUCKS ALLOTED TO GIVEN LOCALITY AS REQUESTED BY THE USER  .ALSO WE TAKE CARE OF OVERFLOWING CONTAINER</p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->
       
       <div id="ref" class="section background-light">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center">
                        </div>
            <div class="col-md-6">
              <div class="service-block text-center">
                <i class="fa fa-rocket"></i>
                <h3>INCREASE THE NUMBER OF CONTAINER</h3>
                <p>AFTER  GETTING THE REQUEST FROM THE USER WE CHECK REASON AND WE FIND THE REASON APPROPRIATE WE INCEREASE  THE NUMBER OF CONTAINER IN THAT  LOCALITY  </p>
                <a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
              </div><!--/.service-block-->
            </div>
            <div class="col-md-6">
              <div class="service-block text-center">
                <i class="fa fa-rocket"></i>
                <h3>INCREASE THE NUMBER OF TRUCKS</h3>
                <p>AFTER  GETTING THE REQUEST FROM THE USER WE CHECK REASON AND WE FIND THE REASON APPROPRIATE WE INCEREASE  THE NUMBER OF TRUCKS  IN THAT  LOCALITY.WE HIRE NEW DRIVERS ETC</p>
                <a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
              </div><!--/.service-block-->
            </div>
          </div>
        </div>
      </div>
      
  		<!-- START SECTION -->
  		

      <div id="ref" class="section background-light">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center">
                        </div>
            <div class="col-md-6">
              <div class="service-block text-center">
                <i class="fa fa-rocket"></i>
                <h3>INCREASE THE NUMBER OF CONTAINER</h3>
                <p>AFTER  GETTING THE REQUEST FROM THE USER WE CHECK REASON AND WE FIND THE REASON APPROPRIATE WE INCEREASE  THE NUMBER OF CONTAINER IN THAT  LOCALITY  </p>
                <a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
              </div><!--/.service-block-->
            </div>
            <div class="col-md-6">
              <div class="service-block text-center">
                <i class="fa fa-rocket"></i>
                <h3>INCREASE THE NUMBER OF TRUCKS</h3>
                <p>AFTER  GETTING THE REQUEST FROM THE USER WE CHECK REASON AND WE FIND THE REASON APPROPRIATE WE INCEREASE  THE NUMBER OF TRUCKS  IN THAT  LOCALITY.WE HIRE NEW DRIVERS ETC</p>
                <a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
              </div><!--/.service-block-->
            </div>
          </div>
        </div>
      </div>
      
  		<!--/.section -->

  		<!-- START SECTION -->
  		
  		<!--/.section -->

  		<!-- START SECTION -->
      <!--SEXTION FOR  REQUEST FOR  INCREASING CONTAINER IN THE LOCALITY-->
  		 
      
  		<!-- START SECTION -->
  		<div class="section hero text-center background-light">
  			<div class="background-image" style="background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRb5_s13TyKyWtcSTLV5lxd1PueSxH_Q1wKRI_pA6r7v1a72ezL') no-repeat fixed center center; background-size: cover; opacity: .4;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h3 class="text-uppercase letter-spacing-md font-weight-lg margin-zero">Laudantium ullam consequatur repellat debitis maxime.</h3>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div class="section background-dark dark-bg">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-3">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">WORKING HOURS</h3>
  						<p>8 AM :12 PM</p>
  						<p><BR>1 PM :6 PM</p>
              <p><BR>7 PM :10 PM</p>
  					</div>
  					<div class="col-md-4 col-md-offset-1">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">OUR ADDRESS</h3>
  						<address>
							<strong>BUILDING NO.3</strong><br>
						 	LOHIYA STREET,GHATKOPAR<br>
						 	MUMBAI-400064<br>
						  (123) 456-7890
						</address>
						<address>
							<strong>Full Name</strong><br>
						 	<a href="mailto:#">Mumbai@wastemanagement.com</a>
						</address>
  					</div>
  					<div class="col-md-4">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">Major contacts</h3>
  						<address>
							555-555555-55<br>
						 	44-4444444-444<br>
						 	55-55555-555<br>
						 	
						</address>
						<address>
													</address>
  					</div>
  					<div class="col-md-12 margin-top-md margin-bottom-md" style="opacity: .2;">
  						<hr/>
  					</div>
  					<div class="col-md-12 margin-top-md text-center font-size-sm text-upercase">
  						<p><a href="http://nomadtheme.com" title="nomadtheme"><strong>Mumbai@wastemanagement.com</strong></a></p>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->
  
  		<!-- jQuery -->
  		<script src="//code.jquery.com/jquery.js"></script>
  		<!-- Bootstrap JavaScript -->
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  	</body>
  </html>