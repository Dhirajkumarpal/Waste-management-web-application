<?php
session_start();
session_destroy();
setcookie('username',$user_id,time()-1);
echo "You have successfully logged out!"."<br>";
//echo "Click here to <a href='../login/index.php'>login again.</a>";
header("Location: ../landinghomepage/AD/index.html");
?>