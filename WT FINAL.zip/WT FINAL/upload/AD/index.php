  <!DOCTYPE html>
  <html lang="">
  	<head>
  		<meta charset="utf-8">
  		<meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<title>Waste Management</title>
  
  		<!-- Bootstrap CSS -->
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  		<!-- Google Fonts -->
  		<link href='https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700' rel='stylesheet' type='text/css'>
  		<!-- Font Awesome -->
  		<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css' rel='stylesheet' type='text/css'>
  		<!-- Style -->
  		<link href='style.css' rel='stylesheet' type='text/css'>
      <style type="text/css">
        .i1{
          height: 10px;
          width: 30px;
          background-color: green;
        }
      </style>
      <script type="text/javascript">
        function  givealert1(){
          alert("IMAGE UPLOADED SUCCESSFULLY");

        }
      </script>
  
  		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  		<!--[if lt IE 9]>
  			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
  			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  		<![endif]-->
  	</head>
  	<body>
  		<nav class="navbar navbar-default" role="navigation">
  			<div class="container">
  				<!-- Brand and toggle get grouped for better mobile display -->
  				<div class="navbar-header">
  					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
  						<span class="sr-only">Toggle navigation</span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  					</button>
  					<a class="navbar-brand" href="#">Waste Management</a>
  				</div>
  		
  				<!-- Collect the nav links, forms, and other content for toggling -->
  				<div class="collapse navbar-collapse navbar-ex1-collapse">
  					<ul class="nav navbar-nav navbar-right">
  						<li><a href="../../homepage/AD/index.html">HOME</a></li>
  						<li><a href="../../about us page/AD/index.php">ABOUT US</a></li>
  						<li><a href="../../localitylocation/AD/index.php">LOCATE</a></li>
  						<li><a href="../../upload/AD/index.html">REQUESTS</a></li>
  						<li><a href="../../logout/logout.php">LOGOUT</a></li>
  					</ul>
  				</div><!-- /.navbar-collapse -->
  			</div>
  		</nav>
		
		<!-- START SECTION -->
  		<div class="section hero text-center background-dark dark-bg">
  			<div class="background-image" style="background: url('https://previews.123rf.com/images/fgnopporn/fgnopporn1211/fgnopporn121100029/16248320-Green-energy-concept-Stock-Photo-energy-environment-clean.jpg') no-repeat center center; background-size: cover; opacity: .4;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h2>CLICK HERE TO UPLOAD THE  FILE</h2>
  						<p class="lead">AND HELP IN OUR GOAL</p>
  						<ul class="list-inline">
  							<li><a href="#upload" title="Learn More" class="btn btn-primary">Click </a></li>
  					
  						</ul>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div class="section background-light">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12 text-center">
  						<h2 class="section-title">Our Services</h2>
  						<p class="section-description">SERVICES RELATED TO  THE USER.</p>
  					</div>
  					<div class="col-md-6">
  						<div class="service-block text-center">
  							<img  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXTYoVvhEdT3qG7BZQYgtTykN2hofchZlMyAH-J7Elwk_9tgoxTA">
                <br>
                <br>
  							<h3>IF FOUND WASTE NOT COLLECTED FROM THE LOCALITY</h3>
  							<p>WHEN YOU FOUND THAT WASTE NOT COLLECTED FROM YOUR LOCLAITY THEN MAKE A CALL TO US OR TAKE THE IMAGE AND UPLOAD IT TO THIS WEBPAGE</p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  					<div class="col-md-6">
  						<div class="service-block text-center">
  							<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAHwAfAMBEQACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgECAwUHBAj/xABIEAABAwIEAQYHCRADAQAAAAABAAIDBBEFBhIhMRNBUXHR4RQWMmGSk7EHIlViZIGRobIVIyUzQkRFUlNUcoLBwuLwY4OjNP/EABoBAQADAQEBAAAAAAAAAAAAAAABBAUDAgb/xAA0EQACAQIEBAMGBgIDAAAAAAAAAQIDEQQUIVESMUFSBRPwFWFxgZGhIjKxwdHhYvEjM0L/2gAMAwEAAhEDEQA/AO4oAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIDw4tidPhVNy9QXEF2lrWi5cV0pUpVJcKOVWtGlHikaHx0YTtROt55O5Wsi+4pe0V2lfHIc1CT/wBvcpyL7h7RXaVGcPkJ9d3JkH3D2iu0r43/ACE+u7kyD7h7RXaWOzhIPzBlvPP/AIo8Elzl9v7C8Qb5Q+/9FW5vdvroQOqb/FS8A+kgvEV1iV8cPkJ9d3KMg+4e0V2lDnH5D/7dyZF9w9ortBzk0fmTvWdyZF9w9ortPRQZtpqmpZBNC+EvcGtdcEXPC651MHOKunc6U8dCTs1YkQ4KoXiqAIAgCAhvuiP0toRfYl59ivYLnIzfEeUfmcVzHmzFcOxqppaUwCGPTp1xXO7QTvfpJVqpUkpWRzo4enOCkzwNz1jv61N6nvXnzJHR4Wl6ZcM946PyqX1Pep8yRGVpbfcuGe8d/XpPUd6nzJDLUtvuXjPGYDwdS+o71PHM8+RRW/1LxnXHud1N6nvXrimeXSpA5zzBa+qm9R3peZCp0fTMLs74+OLqX1HevDnM6LD0fTLHZ4x3ndS+p7158yZOWpbfcmmWcTqMRwWmrKot5dzn3LBYbPIHsXWDco6lKtBQqWR3VvkjqWIfQFUAQBAEBB/dLdpGH9cn9qvYLnIzfEeUfmcIxyCOqzRiYkvaKDldiBe0bNtyPOoqxc6steSudcPJRoRuubt92Rx1g9wa64BO+39LqnxPcuWRIMu4TR4hQSzVbpQ9sxYC121tIP8AUrVwGFhXpuU7897GXj8VUoTUYbbG0p8uYU+qijdy72PdYhs+kn5zsFbreH0lBuLd/iUo+IYmTsrfQ8M2E0/hYjw9s7QIWukE7gTck8PNZVsLCFSco0//ADzLlepUpU4yq21PTHg9W2xMWoeZaSw8kZ0sZTfU9cOFG+mSBwXaNBdUcJ4m3JmSoy3FJqaXOgk+O0heZYWE1+EheITpvVXI7iOEyUM7oZHMeQAdTDcELPnRcXZmrTxCnFSRMsp/e8v0zOgyfbcvK0VjjXlep9P0PoNvkjqWGfQFUAQBAEBA/dRNhhvXJ/ar2C5szfEfyxOIYhMyLMmMOfIGa6F7WlztO5Yyw4jf/bKKsb1Z620+vuO+Gnw0Y/hvd216avX4ojdTbl3kP13N9V73+s+1Ui2SXLc9VQ5fqqyCIuibVaS4PsdRYLAC/Vv5udcpVIqoqd9X6/Y9wxFOD8prV6/IlP41lK6lifIHxwO0ytis4lpIuQQbW+fp3WzjaqlhnDrp+qMRYas1KtZWT9dff8TWYu5zMVjeYSzlaZjwGAG4JO9gdrrh4FP8U3bb9z14hhKlKEZVElxaq3wR7KWptazZfRK+rUr9D5ypS+BuYal50E8rwH5JK5tR2Kk00+Zs4Z2vmjE0LnBzW3vHvwHzqm3aGlz3UTzDTta/uOe58IjzLWMhjMcY0WaRa3vGlVOOTV2fSYenGMEkbPLb/wABQb87/tFeeh4q/wDZ9D6Kb5I6liH0CKoAgCAICBe6p+Lw0/Gk9jVdwXNmd4j+WJwzFOX8ZMRNMxr3+DbhxI0jQ25BB2PQVxxTSqu5YwcXKgrdLvrv7v8ARoqkkS6HQRRkG9mkn67rgWTe5UbgxjIxvCcTxCMzG4ohqsNA2IDmm99+NutRwycr9DsvK8l6fj36W09/x6G3pWZThktiWV8xBokILdL7na37RtjrB26NrrxxOOk2eK9XDK0abtvey+1366HjjlwmOvk+51JXUMWgXZWG7idR4bmwtZbnhlSjeXB7rmFjvOqRV5KWrtryXr/Ztqeuo22vI49TVuqtDcxZ0Kr6G1p8Tpxp0NkNrdATWXUqzw7vdm0ZizTKJIYA4gD30htzLisO+G0meavD5jn/AD+1iC5wqBVY3UzvdGXP03Ebg4AhoHEdSpTjCOiN/Dcflq/M2WXbDB6cDhd/2iuHQmq/+T6H0a3yR1LEPoCqAIAgCAgPurfisN/jk9gV3B85Gd4j+WJw7GNsaryxlSXGncHeDEh1tLPK2tp6fN8y8Yimp1XdXtr9Dvg6jhRWtr6f0R+bSHEGOZrv+R24+pVS0Tf3O6mppKGtnpoBKYpHPJcTpjOhrQ8t4GxN1qYPDRq0edney+i/szcZXlTqNK7jZNrTo38/0JxiWX/AcvNrJcRjmkY9jna5XWOpwB1A7XuTw4FZToqvU4XJL3v16uaEoU6FsTKLvp1010/c59niGOlrqKSKpgmE9MHkQkHk9+BtzqxgIKk5JNP4HjF1Y4hRlE0cdTZa0aljNlSue2PFuTHV51YWKsVpYS7MFRjU0gLeUOnoC5Txcnpc608FCOtjXyT6je9lWc7lpU7E0yy/Vg1KfjO+2V7WsSjXVqv0PpJvkjqWKb5VAEAQBAc/91l1ocN/jk9jVdwXNmd4h+WJy6TDqeWeWZ+7pWlrthwIaCOqzfrKsSoKUnK7VyrTxUoRUbJ2MHi9hpFuSaOpjexc8nDdnX2hU2Xr5maLBqeGJ0dPNLC137Ozd+nYcdl1hRlTVoTaXuZznivMd5wi370bFrq11K+lqsYxGqp3OjPJVFS57QGP1AAX4cx8wC5TwMJ/mJeNm9Gk0aOqyvS1Eplmrq0uJP5Y2vzDZQsJTpLS6vseqeKlqoxSLPFCi/faz0m9i65b/JkZ2XaihyhQ/vlZ6TexRlv8mM7PtXr5lG5RoWuDvCao25iW9iZZdzJz09l6+Zf4sYe0k8pKQb7Ejn+bm5kyy7mM9U7V6+ZtqSKOlijhiADGnawtxN11jHgja5WqTdSfEz6IZ5I6ljH0BVAEAQFCbICCZ1pjmcwUVCQ10DzJy/MBax+Y7fQr1GPkx45dTNry8+apw6dSJjJNaJzC+va08xMfldNh5tt/OuuajbkcslK9rl0WTqmSJjjVvD7tD2WF2Ei++21rpmYp2IWElYytyVMXN/CDhG8NLJNrOLr2HD/bqcytmTlHui4ZJnLf/tl5QbmMNBda9r8EzMbkZORcckyC5diL+TaHF0gF2t08Qdv93TMrZk5SW6KHJFQ0AOrpA8mwaR5W1/e7b7JmYkZOS52KeJE5k0CukJ2uLbtuCd9tuCjNRsTk5XtdGHxNlLA815DSW++NtO5tsbb77KcytmFhJc7osfk2r1NaKwtLgCGuZd3Gx2twFwozMdhk5Xtcupcm1jHtqHTtqGwPa6WFg3NiCR9CefGT4XpcjKziuJWdjrGF4hHXwh7LBw8pvsPUqFWm6crM0qNZVY3R7lzOwQBARzMGK7vo6c+aV3N/D2/R0q7hcPxfjlyM7F4nh/BA1MOKNoqRzGU7zM513SOdsTfjbjw4BdquHnUndvQ40cTClCyWpgrMbikc0NgkbpudWoFzTYgFvNffnXhYSS6nSWNg7aMwjHIhNq5B4Fmj3rh74i+xvzb3CZSVrXQzsL3s/sUOPUsfKCSnkNO9ukR6huSSXE9d1OVnZa6kZyGv4XYr4z0b7l0NS513Oa4ubdurbZecrPdE56ns/sVGZqMHU2GpDrtu4Obd2npTKz3ROehsy05kodOjweoEem3J6xp43v1planO6uRnafa7FseZaZ07y+CV2p5MR1C7AQAR9IU5WVkkwsdG7bi/cXMxuMBwMc1y5v3wOGp4AHlc1zYjqR4WW6CxsNn9i0YvGYI2CncCxu0er73e4IPTtbbrU5WV73/kjOQslw/wbGLH2tezTA7Rf313b2ttb515yctz1n43/Ky2KudBXGopGcm07lhNxvxHUVY8hyp8M+ZV8/gq8dNWRMaCsiraZs0J2OxaeLT0FZU4OEuFmzTqRqR4keleT2Yqpkj6eRsTtMhYQ13QbbFSmk9TzJNp2OZ4icYoah8f3IqZ2hxtJC8ODvPvZaixdKxjywdY8L6zFXizsAxH6G9qnNUzzlK2xhdJiTv0DiA/lb2pmqe4ylbYt/CJ/QeIeg3tU5mluMpW2LJIsQkADsFxIAb7Mb2pmaW5GVrdpjFLXfA+J+g3tTM09yMpW7Svgtd8D4n6A7UzNPcnJ1tv0Hgtd8D4n6De1MzT3GTrdv6FPBK4EH7j4nt8RvamZpbjKVe0zWxH4ExD0B2pmqW4ytbtLg7ER+gsQP8AK3tTNUtycpW2MjZ8TbwwDEPob2pmqYylbYzNrcXcbDAcQHXp7VGapErCVtiYZMhxDVJUVkDqZjhbknOuSdrE83SqmJrQqJWRdwlCpTbcuRLFULwQCw6EAQCyAIAgCApYdCArZAEAQBALDoQCyAWQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAf/2Q==">
  							<h3>UPLOAD THE IMAGE FROM PC OR LAPTOP OR MOBILE</h3>
  							<p>AFTER YOU UPLOAD THE IMAGE A MAIL WILL BE SENT TO US ALONG WITH THAT IMAGE. WE WILL RECORD YOUR LOCALITY AND AND TAKE ACTION AS SOON AS POSSIBLE</p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  					  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		
  		<!--/.section -->

  		<!-- START SECTION -->
  		
  		<!--/.section -->

  		<!-- START SECTION -->
      <!--SEXTION FOR  REQUEST FOR  INCREASING CONTAINER IN THE LOCALITY-->
  		<!--/.section -->
      


      <div  id="upload" class="section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="section-title">UPLOAD THE IMAGE FILE HERE</h2>
              <p class="section-description">SELECT THE IMAGE YOU WANT TO UPLOAD</p>
              
            </div>
            <div  class="col-md-8 col-md-offset-2">
              <form  action="index.php"  id="contact" method="post" class="form" role="form" enctype="multipart/form-data">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input class="form-control" id="name" name="name" placeholder="Localityname" type="text" required />
                </div>
                <div class="col-md-6 form-group">
                  <input class="form-control" id="email" name="email" placeholder="Email" type="email" required />
                </div>
              </div>

              <input  type="file" name="file">
             <br>
              <div class="row">
                <div class="col-md-12 form-group">
                  <button class="btn btn-primary" type="submit" name="submit">UPLOAD</button>
                </div>
              </div>
            </form>
            </div>
          </div><!--/.row-->
        </div><!--/.container-->
      </div>
      <?php
      if(isset($_POST['submit']))
      {
        $file=$_FILES['file'];

        $fileName=$_FILES['file']['name'];
        $fileTmpname=$_FILES['file']['tmp_name'];
        $fileSize=$_FILES['file']['size'];
        $fileError=$_FILES['file']['error'];
        $fileType=$_FILES['file']['type']; 

        $fileExt=explode('.',$fileName);
        $fileActualExt=strtolower(end($fileExt));
        $allowed=array('jpg','gpeg','png','pdf');
        if(in_array($fileActualExt, $allowed))
        {
            if($fileError === 0)
            {
                if($fileSize < 1000000)
                {
                     //$fileNameNew=uniqid('',true).".".".".$fileActualExt;
                     $fileNameNew="image.".$fileActualExt;
                     $fileDestination = 'uploads/'.$fileNameNew;
                     move_uploaded_file($fileTmpname, $fileDestination);
                     echo "<script>givealert1();</script>";

                     echo '<h3 style="text-align:center;color:green;">Image uploded successfully</h3>';

                     include "../../PHPMailer/test/email.php"; 
                }
                else
                {
                     
                     echo '<h3 style="text-align:center;color:green;">Image size is very large</h3>';
                   
                }
            }
            else
            {
              echo '<h3 style="text-align:center;color:green;">IMAGE OF THIS TYPE CANNOT BE UPLOADED</h3>';
            }
        }
        else
        {
          echo '<h3 style="text-align:center;color:green;">IMAGE OF THIS TYPE CANNOT BE UPLOADED</h3>';
        }


      }

      ?>
  		<!-- START SECTION -->
  		<div class="section hero text-center background-light">
  			<div class="background-image" style="background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRb5_s13TyKyWtcSTLV5lxd1PueSxH_Q1wKRI_pA6r7v1a72ezL') no-repeat fixed center center; background-size: cover; opacity: .4;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h3 class="text-uppercase letter-spacing-md font-weight-lg margin-zero">Laudantium ullam consequatur repellat debitis maxime.</h3>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div class="section background-dark dark-bg">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-3">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">WORKING HOURS</h3>
  						<p>8 AM :12 PM</p>
  						<p><BR>1 PM :6 PM</p>
              <p><BR>7 PM :10 PM</p>
  					</div>
  					<div class="col-md-4 col-md-offset-1">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">OUR ADDRESS</h3>
  						<address>
							<strong>BUILDING NO.3</strong><br>
						 	LOHIYA STREET,GHATKOPAR<br>
						 	MUMBAI-400064<br>
						  (123) 456-7890
						</address>
						<address>
							<strong>Full Name</strong><br>
						 	<a href="mailto:#">Mumbai@wastemanagement.com</a>
						</address>
  					</div>
  					<div class="col-md-4">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">Major contacts</h3>
  						<address>
							555-555555-55<br>
						 	44-4444444-444<br>
						 	55-55555-555<br>
						 	
						</address>
						<address>
													</address>
  					</div>
  					<div class="col-md-12 margin-top-md margin-bottom-md" style="opacity: .2;">
  						<hr/>
  					</div>
  					<div class="col-md-12 margin-top-md text-center font-size-sm text-upercase">
  						<p><a href="http://nomadtheme.com" title="nomadtheme"><strong>Mumbai@wastemanagement.com</strong></a></p>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->
  
  		<!-- jQuery -->
  		<script src="//code.jquery.com/jquery.js"></script>
  		<!-- Bootstrap JavaScript -->
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  	</body>
  </html>