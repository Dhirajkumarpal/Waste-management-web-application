  <!DOCTYPE html>
  <html lang="">
  	<head>
  		<meta charset="utf-8">
  		<meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<title>Waste Management</title>
  
  		<!-- Bootstrap CSS -->
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  		<!-- Google Fonts -->
  		<link href='https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700' rel='stylesheet' type='text/css'>
  		<!-- Font Awesome -->
  		<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css' rel='stylesheet' type='text/css'>
  		<!-- Style -->
  		<link href='style.css' rel='stylesheet' type='text/css'>
  
  		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  		<!--[if lt IE 9]>
  			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
  			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  		<![endif]-->
      <script type="text/javascript">
        define showmessage(){
        $("#1").show("slow");
        $("#1").hide("fast");
       }

        define showmessage1(){
        $("#2").show("slow");
        $("#2").hide("fast");
       }


      </script>
      <style type="text/css">
        #1{
          align-content: center;
          text-align: center;
          background-color: green;
          height: 20px;
          width:40%;
          display: none;



        }
        .map{
          width: 95%;
          height: 700px;
          border-width: 10px;
          border-color: black;
        }
        #2{
          align-content: center;
          text-align: center;
          background-color: green;
          height: 20px;
          width:40%;
          display: none;
          


        }
      </style>
  	</head>
  	<body>
      <?php
       $servername = "localhost";
$username = "username";
$password = "password";
$dbname = "wm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 



      ?>
  		<nav class="navbar navbar-default" role="navigation">
  			<div class="container">
  				<!-- Brand and toggle get grouped for better mobile display -->
  				<div class="navbar-header">
  					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
  						<span class="sr-only">Toggle navigation</span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  						<span class="icon-bar"></span>
  					</button>
  					<a class="navbar-brand" href="#">WASTE MANAGEMENT</a>
  				</div>
  		
  				<!-- Collect the nav links, forms, and other content for toggling -->
  				<div class="collapse navbar-collapse navbar-ex1-collapse">
  					<ul class="nav navbar-nav navbar-right">
  						<li><a href="../../homepage/AD/index.html">HOME</a></li>
  						<li><a href="../../about us page/AD/index.php">ABOUT US</a></li>
  						<li><a href="../../requestfulfilling/AD/index.php">REQUEST</a></li>
              <li><a href="../../upload/indigo/index.php">UPLOAD</a></li>
  						<li><a href="../../logout/logout.php">LOG OUT</a></li>
  					</ul>
  				</div><!-- /.navbar-collapse -->
  			</div>
  		</nav>
		
		<!-- START SECTION -->
  		<div class="section hero text-center background-dark dark-bg">
  			<div class="background-image" style="background: url('http://www.thelittlesnowball.com/wp-content/uploads/2016/12/20131210-reduce-reuse-recycle-03.jpg') no-repeat center center; background-size: cover; opacity: .6;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h2>CLICK HERE TO </h2>
  						<p class="lead">GET LOCATION OF DUMPING PLACE</p>
  						<ul class="list-inline">
  							<li><a href="#ref" title="Learn More" class="btn btn-md btn-info" >Click </a></li>
  					
  						</ul>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div class="section background-light">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12 text-center">
  						<h2 class="section-title">Our Services</h2>
  						<p class="section-description">SERVICES RELATED TO THE REQUEST FROM THE USER.</p>
  					</div>
  					<div class="col-md-6">
  						<div class="service-block text-center">
  							<i class="fa fa-rocket"></i>
  							<h3>KNOW LOCATION</h3>
  							<p>DONT KNOW WHERE TO PUT THE WASTE IN YOUR LOCALITY WE HELP YOU TO GET KNOW.KNOW THE DUMPING PLACE IN YOUR LOCALITY USING  THIS WEB PAGE </p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  					<div class="col-md-6">
  						<div class="service-block text-center">
  							<i class="fa fa-rocket"></i>
  							<h3>GIVE YOUR LOCALITY NAME</h3>
  							<p>INPUT YOUR LOCALITY IN INPUT FIELD AND CLICK THE SHOW LOCALTION BUTTON .A MAP WILL APPEAR  SHOWING YOUR  DUMPING PLACE  IN THE LOCLATY </p>
  							<a href="#" title="Learn More" class="btn btn-sm btn-primary">Learn More</a>
  						</div><!--/.service-block-->
  					</div>
  					  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		
  		<!--/.section -->

  		<!-- START SECTION -->
  		
  		<!--/.section -->

  		<!-- START SECTION -->
      <!--SEXTION FOR  REQUEST FOR  INCREASING CONTAINER IN THE LOCALITY-->
  		<div  id="ref"class="section">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12 text-center">
  						<h2 class="section-title"> HERE YOU CAN  GET THE LOCALITY OF DUMPING PLACE</h2>
  						<p class="section-description">ENTER YOUR AREA NAME TO </p>
               <p class="section-description">GET THE DUMPING LOCATION ON MAP</p>
  					</div>
  					<div class="col-md-8 col-md-offset-2">
  						<form action="index.php" id="contact" method="post" class="form" role="form">
							<div class="row">
								<div class="col-md-6 form-group">
									<input class="form-control" id="name" name="name" placeholder="Localityname" type="text" required />
								</div>
								<div class="col-md-6 form-group">
									<input class="form-control" id="email" name="email" placeholder="Email" type="email" required />
								</div>
							</div>
		
							<br />
							<div class="row">
								<div class="col-md-12 form-group">
									<button class="btn btn-primary" name="submit" type="submit">Show Location</button>
								</div>
							</div>
						</form>
  					</div>
  				</div><!--/.row-->
           
      
      
  			</div><!--/.container-->
  		</div>
  		<!--/.section -->
      
     <?php  
      if(isset($_POST['submit'])){
        
        $Localityname=$_POST['name'];
        $email=$_POST['email'];
      
        $sql="select * from location_in_map where  locality='$Localityname'";
        $result=mysqli_query($conn,$sql);
        
        $_POST['name']=$Localityname;
        $_POST['email']=$email;
        if(mysqli_num_rows($result) > 0)
                        {
                           echo '<h1 style="text-align:center;color:green">SEE THE LOCATION BELOW</h1>';
                          while($row = mysqli_fetch_assoc($result))
                          { echo '<div style="width:100% ;height:700px;border:5px solid black;">';
                            echo $row['google_map_location'];
                            echo '</div>';
                          }
                          
                        }
       else
       {
         echo '<h2 style="text-align:center;font-color:green">REPLY MSG :This Locality does not comes under our control</h2>';

       }
     }
    

      ?>
     

  		<!-- START SECTION -->
  		<div class="section hero text-center background-light">
  			<div class="background-image" style="background: url('http://www.corehealthbemidji.com/shutterstock_296046404.jpg') no-repeat fixed center center; background-size: cover; opacity: .4;"></div>
  			<div class="container">
  				<div class="row">
  					<div class="col-md-12">
  						<h3 class="text-uppercase letter-spacing-md font-weight-lg margin-zero">USE 3R's TO SAVE THE EARTH.</h3>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->

  		<!-- START SECTION -->
  		<div class="section background-dark dark-bg">
  			<div class="container">
  				<div class="row">
  					<div class="col-md-3">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">WORKING HOURS</h3>
  						<p>8 AM :12 PM</p>
  						<p><BR>1 PM :6 PM</p>
              <p><BR>7 PM :10 PM</p>
  					</div>
  					<div class="col-md-4 col-md-offset-1">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">OUR ADDRESS</h3>
  						<address>
							<strong>BUILDING NO.3</strong><br>
						 	LOHIYA STREET,GHATKOPAR<br>
						 	MUMBAI-400064<br>
						  (123) 456-7890
						</address>
						<address>
							<strong>Full Name</strong><br>
						 	<a href="mailto:#">Mumbai@wastemanagement.com</a>
						</address>
  					</div>
  					<div class="col-md-4">
  						<h3 class="text-uppercase font-size-md letter-spacing-md font-weight-lg ">Major contacts</h3>
  						<address>
							555-555555-55<br>
						 	44-4444444-444<br>
						 	55-55555-555<br>
						 	
						</address>
						<address>
													</address>
  					</div>
  					<div class="col-md-12 margin-top-md margin-bottom-md" style="opacity: .2;">
  						<hr/>
  					</div>
  					<div class="col-md-12 margin-top-md text-center font-size-sm text-upercase">
  						<p><a href="http://nomadtheme.com" title="nomadtheme"><strong>Mumbai@wastemanagement.com</strong></a></p>
  					</div>
  				</div>
  			</div>
  		</div>
  		<!--/.section -->
  
  		<!-- jQuery -->
  		<script src="//code.jquery.com/jquery.js"></script>
  		<!-- Bootstrap JavaScript -->
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  	</body>
  </html>